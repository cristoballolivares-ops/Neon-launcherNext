package com.neon.launcher

import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppPagerAdapter(
    private val onClick: (AppEntry) -> Unit,
    private val onLongClick: (AppEntry) -> Unit,
    private val onHomeDrawer: () -> Unit
) : RecyclerView.Adapter<AppPagerAdapter.PageHolder>() {

    companion object { const val ROWS = 5 }

    private var apps: List<AppEntry> = emptyList()
    private var cols = 4
    private val perPage: Int get() = cols * ROWS

    class PageHolder(view: View) : RecyclerView.ViewHolder(view)

    fun submit(newApps: List<AppEntry>, newCols: Int) {
        apps = newApps
        cols = newCols
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = 1 + maxOf(1, (apps.size + perPage - 1) / perPage)

    override fun getItemViewType(position: Int): Int = if (position == 0) 0 else 1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageHolder {
        val ctx = parent.context
        if (viewType == 0) {
            return PageHolder(HomeSceneView(ctx, onClick, onHomeDrawer))
        }
        val d = ctx.resources.displayMetrics.density
        val grid = GridLayout(ctx).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
            clipChildren = false
        }
        return PageHolder(grid)
    }

    override fun onBindViewHolder(holder: PageHolder, position: Int) {
        if (position == 0) {
            (holder.itemView as HomeSceneView).setApps(apps)
            return
        }
        val grid = holder.itemView as GridLayout
        val ctx = grid.context
        val d = ctx.resources.displayMetrics.density
        grid.removeAllViews()
        grid.columnCount = cols
        grid.rowCount = ROWS

        val start = (position - 1) * perPage
        for (slot in 0 until perPage) {
            val row = slot / cols
            val col = slot % cols
            val lp = GridLayout.LayoutParams(
                GridLayout.spec(row, 1, GridLayout.FILL, 1f),
                GridLayout.spec(col, 1, GridLayout.FILL, 1f)
            ).apply { width = 0; height = 0 }
            val index = start + slot
            if (index >= apps.size) {
                grid.addView(View(ctx), lp)
                continue
            }
            val app = apps[index]
            val cell = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(0, (4 * d).toInt(), 0, (4 * d).toInt())
                setOnClickListener { onClick(app) }
                setOnLongClickListener { onLongClick(app); true }
                pressable()
            }
            val icon = ImageView(ctx).apply {
                setImageDrawable(app.newIcon())
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            cell.addView(icon, LinearLayout.LayoutParams((52 * d).toInt(), (52 * d).toInt()))
            val label = TextView(ctx).apply {
                text = app.label
                textSize = 11f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setShadowLayer(6f, 0f, 2f, Color.BLACK)
                setPadding((2 * d).toInt(), (4 * d).toInt(), (2 * d).toInt(), 0)
            }
            cell.addView(label, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ))
            grid.addView(cell, lp)
        }
    }
}
