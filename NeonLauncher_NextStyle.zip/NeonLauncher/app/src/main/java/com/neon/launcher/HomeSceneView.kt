package com.neon.launcher

import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import android.view.MotionEvent
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Escritorio 3D inspirado en la estética visual de Next Launcher 3D:
 * plataforma central, paneles holográficos, iconos flotantes y perspectiva.
 */
class HomeSceneView(
    context: Context,
    private val onAppClick: (AppEntry) -> Unit,
    private val onDrawer: () -> Unit
) : View(context) {
    private val density = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val cyan = Color.rgb(0, 229, 255)
    private val blue = Color.rgb(65, 125, 255)
    private val magenta = Color.rgb(210, 65, 255)
    private var apps: List<AppEntry> = emptyList()
    private val hitRects = mutableListOf<Pair<RectF, AppEntry>>()
    private val drawerRect = RectF()
    private var phase = 0f
    private var downX = 0f
    private var downY = 0f

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        isClickable = true
    }

    fun setApps(value: List<AppEntry>) {
        apps = value
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        // Perspectiva tipo "escena 3D".
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, h,
            Color.argb(35, 0, 15, 40), Color.argb(150, 0, 0, 8), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, p)
        p.shader = null

        drawPerspectiveGrid(canvas, w, h)
        drawFloatingPanels(canvas, w, h)
        drawPlatform(canvas, w, h)
        drawApps(canvas, w, h)
        drawDrawerButton(canvas, w, h)
    }

    private fun drawPerspectiveGrid(canvas: Canvas, w: Float, h: Float) {
        line.strokeWidth = 1.2f * density
        line.color = Color.argb(85, 0, 229, 255)
        val horizon = h * 0.56f
        for (i in 0..12) {
            val x = w * i / 12f
            canvas.drawLine(w / 2f, horizon, x, h, line)
        }
        for (i in 1..9) {
            val t = i / 9f
            val y = horizon + (h - horizon) * t * t
            canvas.drawLine(0f, y, w, y, line)
        }
        line.color = Color.argb(70, 60, 110, 255)
        canvas.drawLine(0f, horizon, w, horizon, line)
    }

    private fun drawFloatingPanels(canvas: Canvas, w: Float, h: Float) {
        line.strokeWidth = 2f * density
        line.setShadowLayer(12f * density, 0f, 0f, cyan)
        line.color = Color.argb(100, 0, 229, 255)
        val left = Path().apply {
            moveTo(w * .08f, h * .14f)
            lineTo(w * .34f, h * .09f)
            lineTo(w * .34f, h * .46f)
            lineTo(w * .08f, h * .50f)
            close()
        }
        canvas.drawPath(left, line)
        val right = Path().apply {
            moveTo(w * .66f, h * .09f)
            lineTo(w * .92f, h * .14f)
            lineTo(w * .92f, h * .50f)
            lineTo(w * .66f, h * .46f)
            close()
        }
        canvas.drawPath(right, line)
        line.clearShadowLayer()
    }

    private fun drawPlatform(canvas: Canvas, w: Float, h: Float) {
        val cx = w / 2f
        val cy = h * .66f
        val rx = min(w * .34f, 260f * density)
        val ry = rx * .23f
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, rx,
            intArrayOf(Color.argb(130, 0, 229, 255), Color.argb(40, 30, 80, 255), Color.argb(0, 0, 0, 0)),
            floatArrayOf(0f, .55f, 1f), Shader.TileMode.CLAMP)
        canvas.drawOval(cx - rx, cy - ry, cx + rx, cy + ry, p)
        p.shader = null

        line.strokeWidth = 3f * density
        line.color = cyan
        line.setShadowLayer(18f * density, 0f, 0f, cyan)
        canvas.drawOval(cx - rx, cy - ry, cx + rx, cy + ry, line)
        line.clearShadowLayer()

        line.strokeWidth = 1.2f * density
        line.color = Color.argb(150, 170, 80, 255)
        canvas.drawOval(cx - rx * .72f, cy - ry * .52f, cx + rx * .72f, cy + ry * .52f, line)
    }

    private fun drawApps(canvas: Canvas, w: Float, h: Float) {
        hitRects.clear()
        if (apps.isEmpty()) return
        val cx = w / 2f
        val cy = h * .45f
        val radiusX = min(w * .30f, 220f * density)
        val radiusY = min(h * .20f, 150f * density)
        val count = min(8, apps.size)
        val iconSize = 54f * density

        for (i in 0 until count) {
            val angle = (-Math.PI / 2.0) + i * (Math.PI * 2.0 / count)
            val x = cx + cos(angle).toFloat() * radiusX
            val y = cy + sin(angle).toFloat() * radiusY
            drawHex(canvas, x, y, iconSize * .70f, if (i % 2 == 0) cyan else magenta)
            val d = apps[i].newIcon()
            d.setBounds((x - iconSize / 2).toInt(), (y - iconSize / 2).toInt(),
                (x + iconSize / 2).toInt(), (y + iconSize / 2).toInt())
            d.draw(canvas)
            p.textSize = 10f * density
            p.textAlign = Paint.Align.CENTER
            p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            p.color = Color.WHITE
            p.setShadowLayer(6f * density, 0f, 2f, Color.BLACK)
            canvas.drawText(apps[i].label, x, y + iconSize * .72f, p)
            p.clearShadowLayer()
            hitRects += RectF(x - iconSize, y - iconSize, x + iconSize, y + iconSize) to apps[i]
        }

        // Elemento central tipo "nodo" holográfico.
        val nodeY = h * .52f
        line.strokeWidth = 2.5f * density
        line.color = blue
        line.setShadowLayer(16f * density, 0f, 0f, blue)
        canvas.drawCircle(cx, nodeY, 42f * density, line)
        line.clearShadowLayer()
        p.style = Paint.Style.FILL
        p.color = Color.argb(70, 0, 229, 255)
        canvas.drawCircle(cx, nodeY, 30f * density, p)
        p.color = Color.WHITE
        p.textSize = 11f * density
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.DEFAULT_BOLD
        canvas.drawText("NEON", cx, nodeY + 4f * density, p)
    }

    private fun drawHex(canvas: Canvas, cx: Float, cy: Float, r: Float, color: Int) {
        val path = Path()
        for (i in 0 until 6) {
            val a = Math.PI / 3.0 * i - Math.PI / 6.0
            val x = cx + cos(a).toFloat() * r
            val y = cy + sin(a).toFloat() * r
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        line.color = color
        line.strokeWidth = 2.2f * density
        line.setShadowLayer(12f * density, 0f, 0f, color)
        canvas.drawPath(path, line)
        line.clearShadowLayer()
        p.color = Color.argb(42, Color.red(color), Color.green(color), Color.blue(color))
        p.style = Paint.Style.FILL
        canvas.drawPath(path, p)
    }

    private fun drawDrawerButton(canvas: Canvas, w: Float, h: Float) {
        drawerRect.set(w / 2f - 48f * density, h * .82f, w / 2f + 48f * density, h * .82f + 48f * density)
        drawHex(canvas, drawerRect.centerX(), drawerRect.centerY(), 30f * density, cyan)
        p.color = Color.WHITE
        p.textAlign = Paint.Align.CENTER
        p.textSize = 13f * density
        p.typeface = Typeface.DEFAULT_BOLD
        canvas.drawText("APPS", drawerRect.centerX(), drawerRect.centerY() + 5f * density, p)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                return true
            }
            MotionEvent.ACTION_UP -> {
                val dx = event.x - downX
                if (dx < -60f * density) {
                    onDrawer()
                    return true
                }
                if (drawerRect.contains(event.x, event.y)) {
                    onDrawer()
                    return true
                }
                for ((rect, app) in hitRects) {
                    if (rect.contains(event.x, event.y)) {
                        onAppClick(app)
                        return true
                    }
                }
                performClick()
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
